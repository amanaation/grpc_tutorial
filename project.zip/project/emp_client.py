from __future__ import print_function

import logging

import grpc
import jsondata_pb2
import jsondata_pb2_grpc


def run():
    # NOTE(gRPC Python Team): .close() is possible on a channel and should be
    # used in circumstances in which the with statement does not fit the needs
    # of the code.
    with grpc.insecure_channel('localhost:50051') as channel:
        stub = jsondata_pb2_grpc.EmpDataStub(channel)
        d = jsondata_pb2.PastExperience(comp_name="Miko", designation="Develop", years=5)

        emp = jsondata_pb2.Employee(emp_name="Aman", emp_id=23, emp_designation="Data Engineer", past_experience=d)
        response = stub.getEmpDetails(emp)
    print("Greeter client received: " , response.comp_name)


if __name__ == '__main__':
    logging.basicConfig()
    run()
