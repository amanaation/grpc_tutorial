from concurrent import futures
import logging
import json
import grpc
import jsondata_pb2
import jsondata_pb2_grpc
import pandas as pd
from google.protobuf.json_format import Parse


class EmpData:

    def getEmpDetails(self, request, context):
        print("Inside Emp Details")
        print(" ------  ", json.dumps(self.get_data()))

        # emp_details = Parse(json.dumps(self.get_data()[0]), jsondata_pb2.Employee)
        emp_details = self.get_data()
        response = jsondata_pb2.response()

        for emp in emp_details:
            if emp["emp_id"] > 2:
                obj = jsondata_pb2.Employee(emp_name=emp["emp_name"],
                                            emp_id=emp["emp_id"],
                                            emp_designation=emp["emp_designation"])
                response.p.extend([obj])

        res = jsondata_pb2.response()
        return res

    def get_data(self):
        df = pd.read_csv("data.csv")
        json_data = []
        for i in range(len(df)):
            data = {}
            for column in df.columns:
                data[column] = df[column].to_list()[i]
            json_data.append(data)

        return json_data


def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    jsondata_pb2_grpc.add_EmpDataServicer_to_server(EmpData(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    server.wait_for_termination()


if __name__ == '__main__':
    logging.basicConfig()
    serve()
