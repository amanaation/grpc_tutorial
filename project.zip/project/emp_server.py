from concurrent import futures
import logging

import grpc
import jsondata_pb2
import jsondata_pb2_grpc


class EmpData():

    def getEmpDetails(self, request, context):
        print("Inside Emp Details")
        print(" ------  ", request)
        return jsondata_pb2.PastExperience(comp_name="Infy ", designation="SDET", years=5).SerializeToString()


def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    jsondata_pb2_grpc.add_EmpDataServicer_to_server(EmpData(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    server.wait_for_termination()


if __name__ == '__main__':
    logging.basicConfig()
    serve()


