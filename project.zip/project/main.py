import jsondata_pb2

from jsondata_pb2 import PastExperience, Employee, HelloService

p = PastExperience(comp_name="Infosys", designation="SDET", years=3)
d = PastExperience(comp_name="Miko", designation="Develop", years=5)


emp = Employee(emp_name="Aman", emp_id=23, emp_designation="Data Engineer", past_experience=p)
print(emp.SerializeToString())


print(HelloService(p))
#2234196