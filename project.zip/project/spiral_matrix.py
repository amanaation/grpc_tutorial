from typing import List


def spiral_matrix(arr: List[List]):
    m = len(arr)
    n = len(arr[0])
    i = 0
    j = 0
    while (i < m and j < n):
        for p in range(j, n):
            print(arr[i][p])
            # print(" ")
        i = i + 1

        for p in range(i, m):
            print(arr[p][n - 1])
            # print(" ")
        n = n - 1

        if i < m:
            for p in range(n - 1, j - 1, -1):
                print(arr[m - 1][p])
                # print(" ")
            m = m - 1
        if j < n:
            for p in range(m - 1, i - 1, -1):
                print(arr[p][j])
                # print(" ")
            j = j + 1


if __name__ == "__main__":
    arr = [[1, 2, 3, 4, 17],
           [5, 6, 7, 8, 18],
           [9, 10, 11, 12, 19],
           [13, 14, 15, 16, 20],
           [21, 22, 23, 24, 25]]
    spiral_matrix(arr)
